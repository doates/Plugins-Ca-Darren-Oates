var requiredSliderMode = {
    autostart: true,
    canClose: false,
    zoomSize: 'fill',
    canChangeMode: false
};